package com.lunes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LunesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LunesApplication.class, args);
	}

}

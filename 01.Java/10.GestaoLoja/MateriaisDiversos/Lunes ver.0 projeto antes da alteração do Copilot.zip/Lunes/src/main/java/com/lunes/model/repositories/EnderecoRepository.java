package com.lunes.model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lunes.model.entities.Endereco;



public interface EnderecoRepository extends JpaRepository<Endereco, Long>{



}
